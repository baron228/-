def add_array(array: list):
    return sum(array)

print(add_array([1, 2, 3, 4, 5]))
